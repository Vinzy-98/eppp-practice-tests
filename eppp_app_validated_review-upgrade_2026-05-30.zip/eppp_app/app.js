/* ================================================================
   EPPP Practice Test App — Single-page, localStorage-backed
   ================================================================ */

(function () {
  'use strict';

  // ── Storage helpers ──────────────────────────────────────
  const STORAGE_KEY = 'eppp_progress';

  function loadProgress() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY)) || {};
    } catch (e) { return {}; }
  }

  function saveProgress(data) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }

  function getTestAttempts(slug) {
    const p = loadProgress();
    return (p[slug] && p[slug].attempts) || [];
  }

  function saveAttempt(slug, attempt) {
    const p = loadProgress();
    if (!p[slug]) p[slug] = { attempts: [] };
    p[slug].attempts.push(attempt);
    saveProgress(p);
  }

  // ── State ────────────────────────────────────────────────
  let manifest = [];
  const FALLBACK_MANIFEST = [
    { name: 'Ethics and Professional Issues', slug: 'ethics-and-professional-issues', category: 'Category Tests', questionCount: 89, file: 'data/ethics-and-professional-issues.json', jsFile: 'data/ethics-and-professional-issues.js' },
    { name: 'Industrial / Organizational Psychology', slug: 'industrial-organizational-psychology', category: 'Category Tests', questionCount: 1, file: 'data/industrial-organizational-psychology.json', jsFile: 'data/industrial-organizational-psychology.js' },
    { name: 'Learning Theory', slug: 'learning-theory', category: 'Category Tests', questionCount: 91, file: 'data/learning-theory.json', jsFile: 'data/learning-theory.js' },
    { name: 'Lifespan Development', slug: 'lifespan-development', category: 'Category Tests', questionCount: 1, file: 'data/lifespan-development.json', jsFile: 'data/lifespan-development.js' },
    { name: 'Physiological Psychology / Psychopharmacology', slug: 'physiological-psychology-psychopharmacology', category: 'Category Tests', questionCount: 101, file: 'data/physiological-psychology-psychopharmacology.json', jsFile: 'data/physiological-psychology-psychopharmacology.js' },
    { name: 'Psychological Assessment', slug: 'psychological-assessment', category: 'Category Tests', questionCount: 74, file: 'data/psychological-assessment.json', jsFile: 'data/psychological-assessment.js' },
    { name: 'Social Psychology', slug: 'social-psychology', category: 'Category Tests', questionCount: 67, file: 'data/social-psychology.json', jsFile: 'data/social-psychology.js' },
    { name: 'Statistics and Research Design', slug: 'statistics-and-research-design', category: 'Category Tests', questionCount: 65, file: 'data/statistics-and-research-design.json', jsFile: 'data/statistics-and-research-design.js' },
    { name: 'Test Construction', slug: 'test-construction', category: 'Category Tests', questionCount: 67, file: 'data/test-construction.json', jsFile: 'data/test-construction.js' },
    { name: '2025 Academic Review Test 1', slug: '2025-academic-review-test-1', category: 'Full Tests', questionCount: 225, file: 'data/2025-academic-review-test-1.json', jsFile: 'data/2025-academic-review-test-1.js' },
    { name: '2025 Academic Review Test 2', slug: '2025-academic-review-test-2', category: 'Full Tests', questionCount: 225, file: 'data/2025-academic-review-test-2.json', jsFile: 'data/2025-academic-review-test-2.js' },
    { name: '2025 Academic Review Test 3', slug: '2025-academic-review-test-3', category: 'Full Tests', questionCount: 225, file: 'data/2025-academic-review-test-3.json', jsFile: 'data/2025-academic-review-test-3.js' },
    { name: '2025 Academic Review Test 4', slug: '2025-academic-review-test-4', category: 'Full Tests', questionCount: 225, file: 'data/2025-academic-review-test-4.json', jsFile: 'data/2025-academic-review-test-4.js' },
    { name: 'Assessment Exam - EPPP', slug: 'assessment-exam---eppp', category: 'Full Tests', questionCount: 225, file: 'data/assessment-exam---eppp.json', jsFile: 'data/assessment-exam---eppp.js' },
    { name: 'EPPP Exam Simulation - Test 1', slug: 'eppp-exam-simulation---test-1', category: 'Full Tests', questionCount: 224, file: 'data/eppp-exam-simulation---test-1.json', jsFile: 'data/eppp-exam-simulation---test-1.js' },
    { name: 'EPPP Exam Simulation - Test 2', slug: 'eppp-exam-simulation---test-2', category: 'Full Tests', questionCount: 225, file: 'data/eppp-exam-simulation---test-2.json', jsFile: 'data/eppp-exam-simulation---test-2.js' },
    { name: 'Practice Exam 6', slug: 'practice-exam-6', category: 'Full Tests', questionCount: 225, file: 'data/practice-exam-6.json', jsFile: 'data/practice-exam-6.js' },
    { name: 'Practice Exam 7', slug: 'practice-exam-7', category: 'Full Tests', questionCount: 225, file: 'data/practice-exam-7.json', jsFile: 'data/practice-exam-7.js' },
    { name: 'Practice Exam 8', slug: 'practice-exam-8', category: 'Full Tests', questionCount: 225, file: 'data/practice-exam-8.json', jsFile: 'data/practice-exam-8.js' },
    { name: 'Practice Test 2 AR all domains', slug: 'practice-test-2-ar-all-domains', category: 'Full Tests', questionCount: 224, file: 'data/practice-test-2-ar-all-domains.json', jsFile: 'data/practice-test-2-ar-all-domains.js' },
    { name: 'Practice Test AR 1 all domains', slug: 'practice-test-ar-1-all-domains', category: 'Full Tests', questionCount: 224, file: 'data/practice-test-ar-1-all-domains.json', jsFile: 'data/practice-test-ar-1-all-domains.js' }
  ];
  const IS_FILE_PROTOCOL = window.location.protocol === 'file:';
  let currentTest = null;       // { name, slug, category, questionCount, questions }
  let currentIndex = 0;         // current question index
  let userAnswers = {};          // { qIndex: 'A'|'B'|... }
  let timerInterval = null;
  let timerSeconds = 0;
  let lastResults = null;        // stored after submit for review

  // ── DOM refs ─────────────────────────────────────────────
  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => document.querySelectorAll(sel);

  const dashboardView = $('#dashboard-view');
  const testView = $('#test-view');
  const startScreen = $('#test-start-screen');
  const activeScreen = $('#test-active-screen');
  const resultsScreen = $('#test-results-screen');
  const reviewScreen = $('#test-review-screen');

  // ── Init ─────────────────────────────────────────────────
  async function init() {
    try {
      // Use inline manifest if available (file:// protocol), otherwise fetch
      if (window.EPPP_MANIFEST) {
        manifest = window.EPPP_MANIFEST;
      } else if (IS_FILE_PROTOCOL) {
        manifest = FALLBACK_MANIFEST;
      } else {
        var resp = await fetch('tests-manifest.json');
        manifest = await resp.json();
      }

      if (!Array.isArray(manifest) || manifest.length === 0) {
        manifest = FALLBACK_MANIFEST;
      }

      renderDashboard();
      bindEvents();
    } catch (e) {
      console.error('Failed to initialize app:', e);
      var app = document.getElementById('app');
      if (app) {
        app.innerHTML = '<div style="max-width:600px;margin:4rem auto;padding:2rem;text-align:center;font-family:sans-serif;">' +
          '<h2 style="color:#dc3545;">Failed to load tests</h2>' +
          '<p style="margin:1rem 0;color:#666;">The app could not load test data. This can happen if:</p>' +
          '<ul style="text-align:left;margin:1rem auto;max-width:400px;color:#444;">' +
          '<li>JavaScript files were blocked by your browser or antivirus</li>' +
          '<li>Files were not fully extracted from the zip</li>' +
          '<li>The <code>data/</code> folder is missing</li>' +
          '</ul>' +
          '<p style="margin-top:1.5rem;color:#666;">Try using a local server instead:<br><code>python -m http.server 8080</code></p>' +
          '<p style="margin-top:0.75rem;color:#666;">On Windows, use <code>start.bat</code> from this folder.</p>' +
          '</div>';
      }
    }
  }

  // ── Dashboard ────────────────────────────────────────────
  function renderDashboard() {
    const categoryGrid = $('#category-tests-grid');
    const fullGrid = $('#full-tests-grid');
    categoryGrid.innerHTML = '';
    fullGrid.innerHTML = '';

    const progress = loadProgress();

    manifest.forEach(t => {
      const grid = t.category === 'Category Tests' ? categoryGrid : fullGrid;
      const attempts = (progress[t.slug] && progress[t.slug].attempts) || [];
      const best = attempts.length ? Math.max(...attempts.map(a => a.pct)) : null;

      const card = document.createElement('div');
      card.className = 'test-card';
      card.dataset.slug = t.slug;
      card.dataset.file = t.file;

      let badge = '';
      if (best !== null) {
        badge = `<span class="test-card-badge badge-best">${Math.round(best)}%</span>`;
      }

      card.innerHTML = `
        ${badge}
        <div class="test-card-name">${esc(t.name)}</div>
        <div class="test-card-meta">
          <span>${t.questionCount} questions</span>
          <span>${attempts.length} attempt${attempts.length !== 1 ? 's' : ''}</span>
        </div>
      `;
      grid.appendChild(card);
    });

    updateStats();
    renderHistory();
    showView('dashboard');
  }

  function updateStats() {
    const progress = loadProgress();
    let totalAttempts = 0;
    let totalQuestions = 0;
    let scores = [];

    for (const slug in progress) {
      const att = progress[slug].attempts || [];
      totalAttempts += att.length;
      att.forEach(a => {
        totalQuestions += a.total;
        scores.push(a.pct);
      });
    }

    $('#stat-tests-taken').textContent = totalAttempts;
    $('#stat-questions-answered').textContent = totalQuestions;
    $('#stat-avg-score').textContent = scores.length ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) + '%' : '—';
    $('#stat-best-score').textContent = scores.length ? Math.round(Math.max(...scores)) + '%' : '—';
  }

  function renderHistory() {
    const progress = loadProgress();
    const allAttempts = [];

    for (const slug in progress) {
      const meta = manifest.find(m => m.slug === slug);
      (progress[slug].attempts || []).forEach((a, idx) => {
        allAttempts.push({ ...a, slug, name: meta ? meta.name : slug, attemptNum: idx + 1 });
      });
    }

    // Sort by date descending
    allAttempts.sort((a, b) => new Date(b.date) - new Date(a.date));

    const section = $('#history-section');
    const list = $('#history-list');

    if (allAttempts.length === 0) {
      section.style.display = 'none';
      return;
    }

    section.style.display = '';
    list.innerHTML = '';

    allAttempts.slice(0, 20).forEach(a => {
      const item = document.createElement('div');
      item.className = 'history-item';
      item.dataset.slug = a.slug;
      item.dataset.attemptIndex = a.attemptNum - 1;
      item.innerHTML = `
        <div>
          <div class="history-item-name">${esc(a.name)} <span style="color:#999;font-size:0.8rem">#${a.attemptNum}</span></div>
          <div class="history-item-detail">${formatDate(a.date)} · ${a.time} · ${a.correct}/${a.total}</div>
        </div>
        <div class="history-item-score">${Math.round(a.pct)}%</div>
      `;
      list.appendChild(item);
    });
  }

  // ── Events ───────────────────────────────────────────────
  function bindEvents() {
    // Test card click
    document.addEventListener('click', async (e) => {
      const card = e.target.closest('.test-card');
      if (card) {
        const slug = card.dataset.slug;
        const file = card.dataset.file;
        await loadTest(slug, file);
        return;
      }

      const histItem = e.target.closest('.history-item');
      if (histItem) {
        const slug = histItem.dataset.slug;
        const attemptIdx = parseInt(histItem.dataset.attemptIndex, 10);
        const meta = manifest.find(m => m.slug === slug);
        if (meta) {
          await loadTestForReview(meta, attemptIdx);
        }
        return;
      }
    });

    $('#btn-start-test').addEventListener('click', startTest);
    $('#btn-back-dashboard').addEventListener('click', () => renderDashboard());
    $('#btn-exit-test').addEventListener('click', () => confirmAction('Exit this test? Your progress will be lost.', () => { stopTimer(); renderDashboard(); }));
    $('#btn-prev').addEventListener('click', () => navigateQuestion(-1));
    $('#btn-next').addEventListener('click', () => navigateQuestion(1));
    $('#btn-prev-bottom').addEventListener('click', () => navigateQuestion(-1));
    $('#btn-next-bottom').addEventListener('click', () => navigateQuestion(1));
    $('#btn-submit-test').addEventListener('click', () => {
      const answered = Object.keys(userAnswers).length;
      const total = currentTest.questions.length;
      const unanswered = total - answered;
      const msg = unanswered > 0
        ? `You have ${unanswered} unanswered question${unanswered > 1 ? 's' : ''}. Submit anyway?`
        : 'Submit your test?';
      confirmAction(msg, submitTest);
    });
    $('#btn-review').addEventListener('click', showReview);
    $('#btn-retake').addEventListener('click', retakeTest);
    $('#btn-results-dashboard').addEventListener('click', () => renderDashboard());
    $('#btn-review-back').addEventListener('click', () => showScreen('results'));
    $('#btn-review-dashboard').addEventListener('click', () => renderDashboard());
    $('#btn-review-retake').addEventListener('click', retakeTest);
    $('#btn-review-jump').addEventListener('click', jumpToReviewQuestion);
    $('#review-jump-select').addEventListener('change', jumpToReviewQuestion);
  }

  // ── Load Test ────────────────────────────────────────────
  async function loadTest(slug, file) {
    // Check if already loaded inline
    if (window.EPPP_TESTS && window.EPPP_TESTS[slug]) {
      currentTest = window.EPPP_TESTS[slug];
      showTestStartScreen();
      return;
    }

    // On file:// (common on Windows), fetch to local files may be blocked in Chrome.
    if (IS_FILE_PROTOCOL) {
      const meta = manifest.find(m => m.slug === slug);
      if (meta && meta.jsFile) {
        try {
          await loadScript(meta.jsFile);
          if (window.EPPP_TESTS && window.EPPP_TESTS[slug]) {
            currentTest = window.EPPP_TESTS[slug];
            showTestStartScreen();
            return;
          }
        } catch (e) {
          console.error('Failed to load local test script:', slug, e);
        }
      }
    }

    // Try fetch (works on http server)
    try {
      const resp = await fetch(file);
      currentTest = await resp.json();
      showTestStartScreen();
      return;
    } catch (e) {
      // Fallback: dynamic script loading for file:// protocol
      const meta = manifest.find(m => m.slug === slug);
      if (meta && meta.jsFile) {
        await loadScript(meta.jsFile);
        if (window.EPPP_TESTS && window.EPPP_TESTS[slug]) {
          currentTest = window.EPPP_TESTS[slug];
          showTestStartScreen();
          return;
        }
      }
      console.error('Failed to load test:', slug, e);
      confirmAction('Could not load this test file. On Windows, try running start.bat and opening http://localhost:8080.', function () {});
    }
  }

  function loadScript(src) {
    return new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = src;
      s.onload = resolve;
      s.onerror = reject;
      document.head.appendChild(s);
    });
  }

  async function loadTestForReview(meta, attemptIdx) {
    // Load test data
    if (window.EPPP_TESTS && window.EPPP_TESTS[meta.slug]) {
      currentTest = window.EPPP_TESTS[meta.slug];
    } else {
      if (IS_FILE_PROTOCOL && meta.jsFile) {
        try {
          await loadScript(meta.jsFile);
          currentTest = window.EPPP_TESTS && window.EPPP_TESTS[meta.slug];
        } catch (e) {
          console.error('Failed to load local review test script:', meta.slug, e);
        }
      }

      try {
        if (!currentTest) {
          const resp = await fetch(meta.file);
          currentTest = await resp.json();
        }
      } catch (e) {
        if (meta.jsFile) {
          await loadScript(meta.jsFile);
          currentTest = window.EPPP_TESTS && window.EPPP_TESTS[meta.slug];
        }
        if (!currentTest) return;
      }
    }
    const attempts = getTestAttempts(currentTest.slug);
    if (!attempts[attemptIdx]) return;
    lastResults = attempts[attemptIdx];
    userAnswers = lastResults.answers || {};
    showView('test');
    showScreen('results');
    renderResults();
  }

  function showTestStartScreen() {
    showView('test');
    showScreen('start');

    $('#start-test-name').textContent = currentTest.name;
    $('#start-question-count').textContent = `${currentTest.questionCount} questions`;

    const attempts = getTestAttempts(currentTest.slug);
    if (attempts.length) {
      const best = Math.max(...attempts.map(a => a.pct));
      $('#start-past-attempts').textContent = `${attempts.length} previous attempt${attempts.length > 1 ? 's' : ''} · Best: ${Math.round(best)}%`;
    } else {
      $('#start-past-attempts').textContent = 'No previous attempts';
    }
  }

  // ── Start Test ───────────────────────────────────────────
  function startTest() {
    userAnswers = {};
    currentIndex = 0;
    timerSeconds = 0;
    lastResults = null;

    showScreen('active');
    $('#test-title-bar').textContent = currentTest.name;

    buildQuestionNav();
    renderQuestion();
    updateAnsweredCount();
    startTimer();
  }

  function retakeTest() {
    showScreen('start');
    showTestStartScreen();
  }

  // ── Timer ────────────────────────────────────────────────
  function startTimer() {
    stopTimer();
    timerSeconds = 0;
    updateTimerDisplay();
    timerInterval = setInterval(() => {
      timerSeconds++;
      updateTimerDisplay();
    }, 1000);
  }

  function stopTimer() {
    if (timerInterval) { clearInterval(timerInterval); timerInterval = null; }
  }

  function updateTimerDisplay() {
    const h = String(Math.floor(timerSeconds / 3600)).padStart(2, '0');
    const m = String(Math.floor((timerSeconds % 3600) / 60)).padStart(2, '0');
    const s = String(timerSeconds % 60).padStart(2, '0');
    $('#timer').textContent = `${h}:${m}:${s}`;
  }

  function formatTime(seconds) {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    if (h > 0) return `${h}h ${m}m ${s}s`;
    if (m > 0) return `${m}m ${s}s`;
    return `${s}s`;
  }

  // ── Question Nav ─────────────────────────────────────────
  function buildQuestionNav() {
    const strip = $('#question-nav-strip');
    strip.innerHTML = '';
    strip.classList.remove('expanded');
    currentTest.questions.forEach((_, i) => {
      const btn = document.createElement('button');
      btn.className = 'q-nav-btn';
      btn.textContent = i + 1;
      btn.addEventListener('click', () => { currentIndex = i; renderQuestion(); });
      strip.appendChild(btn);
    });

    // Toggle expand/collapse
    const summary = $('#question-nav-summary');
    summary.onclick = function () {
      const isExpanded = strip.classList.toggle('expanded');
      $('#nav-toggle-icon').classList.toggle('expanded', isExpanded);
    };
  }

  function updateNavStrip() {
    const btns = $$('.q-nav-btn');
    btns.forEach((btn, i) => {
      btn.classList.toggle('answered', userAnswers[i] !== undefined);
      btn.classList.toggle('current', i === currentIndex);
    });

    // Update summary bar
    const total = currentTest.questions.length;
    const answered = Object.keys(userAnswers).length;
    var summaryText = $('#nav-summary-text');
    if (summaryText) summaryText.textContent = 'Q ' + (currentIndex + 1) + ' / ' + total;
    var answeredSummary = $('#nav-answered-summary');
    if (answeredSummary) answeredSummary.textContent = answered + ' answered';
    var progressFill = $('#nav-progress-fill');
    if (progressFill) progressFill.style.width = (answered / total * 100) + '%';
  }

  // ── Render Question ──────────────────────────────────────
  function renderQuestion() {
    const q = currentTest.questions[currentIndex];
    const total = currentTest.questions.length;

    $('#question-number').textContent = `Question ${currentIndex + 1} of ${total}`;
    $('#question-text').textContent = q.question;

    const optionsList = $('#options-list');
    optionsList.innerHTML = '';

    const letters = Object.keys(q.options).sort();
    letters.forEach(letter => {
      const btn = document.createElement('button');
      btn.className = 'option-btn' + (userAnswers[currentIndex] === letter ? ' selected' : '');
      btn.innerHTML = `
        <span class="option-letter">${letter}</span>
        <span class="option-text">${esc(q.options[letter])}</span>
      `;
      btn.addEventListener('click', () => selectOption(letter));
      optionsList.appendChild(btn);
    });

    const isFirst = currentIndex === 0;
    const isLast = currentIndex === total - 1;
    $('#btn-prev').disabled = isFirst;
    $('#btn-next').disabled = isLast;
    $('#btn-prev-bottom').disabled = isFirst;
    $('#btn-next-bottom').disabled = isLast;

    updateNavStrip();
  }

  function selectOption(letter) {
    userAnswers[currentIndex] = letter;
    renderQuestion();
    updateAnsweredCount();
  }

  function navigateQuestion(dir) {
    const newIdx = currentIndex + dir;
    if (newIdx >= 0 && newIdx < currentTest.questions.length) {
      currentIndex = newIdx;
      renderQuestion();
    }
  }

  function updateAnsweredCount() {
    const answered = Object.keys(userAnswers).length;
    const total = currentTest.questions.length;
    $('#answered-count').textContent = `${answered} of ${total} answered`;
  }

  // ── Submit ───────────────────────────────────────────────
  function submitTest() {
    stopTimer();

    let correct = 0;
    const total = currentTest.questions.length;

    currentTest.questions.forEach((q, i) => {
      if (userAnswers[i] === q.correct) correct++;
    });

    const pct = (correct / total) * 100;
    const timeStr = formatTime(timerSeconds);

    lastResults = {
      date: new Date().toISOString(),
      correct,
      total,
      pct,
      time: timeStr,
      seconds: timerSeconds,
      answers: { ...userAnswers }
    };

    saveAttempt(currentTest.slug, lastResults);
    showScreen('results');
    renderResults();
  }

  function renderResults() {
    const { correct, total, pct, time } = lastResults;

    $('#results-test-name').textContent = currentTest.name;
    $('#score-pct').textContent = `${Math.round(pct)}%`;
    $('#score-correct').textContent = correct;
    $('#score-total').textContent = total;
    $('#score-time').textContent = time;

    const circle = $('#score-circle');
    circle.classList.remove('score-high', 'score-mid', 'score-low');
    if (pct >= 70) circle.classList.add('score-high');
    else if (pct >= 50) circle.classList.add('score-mid');
    else circle.classList.add('score-low');
  }

  // ── Review ───────────────────────────────────────────────
  function showReview() {
    showScreen('review');

    $('#review-title').textContent = currentTest.name;
    $('#review-score-badge').textContent = `${lastResults.correct}/${lastResults.total} (${Math.round(lastResults.pct)}%)`;

    const list = $('#review-list');
    const jumpSelect = $('#review-jump-select');
    const questionMap = $('#review-question-map');
    list.innerHTML = '';
    jumpSelect.innerHTML = '';
    questionMap.innerHTML = '';

    currentTest.questions.forEach((q, i) => {
      const selected = lastResults.answers[i];
      const status = getReviewStatus(i, q.correct);
      const isCorrect = status === 'correct';

      const option = document.createElement('option');
      option.value = String(i);
      option.textContent = `Q${i + 1} - ${statusLabel(status)}`;
      jumpSelect.appendChild(option);

      const mapBtn = document.createElement('button');
      mapBtn.className = `review-map-btn ${status}`;
      mapBtn.textContent = i + 1;
      mapBtn.title = `Question ${i + 1}: ${statusLabel(status)}`;
      mapBtn.addEventListener('click', () => scrollToReviewQuestion(i));
      questionMap.appendChild(mapBtn);

      const item = document.createElement('div');
      item.className = 'review-item ' + (status === 'correct' ? 'correct' : status === 'incorrect' ? 'incorrect' : 'unattempted');
      item.id = `review-q-${i}`;

      let optionsHtml = '';
      const letters = Object.keys(q.options).sort();
      letters.forEach(letter => {
        let cls = 'review-option';
        let tag = '';
        if (letter === q.correct && letter === selected) {
          cls += ' is-selected-correct';
          tag = '<span class="review-tag">✓ Your answer (Correct)</span>';
        } else if (letter === q.correct) {
          cls += ' is-correct';
          tag = '<span class="review-tag">✓ Correct answer</span>';
        } else if (letter === selected) {
          cls += ' is-selected-wrong';
          tag = '<span class="review-tag">✗ Your answer</span>';
        }
        optionsHtml += `<div class="${cls}"><span class="opt-letter">${letter}.</span> <span>${esc(q.options[letter])}</span>${tag}</div>`;
      });

      const selectedText = selected ? selected : 'Not attempted';
      const resultText = status === 'correct' ? 'Correct' : status === 'incorrect' ? 'Incorrect' : 'Unattempted';

      item.innerHTML = `
        <div class="review-q-num">Question ${i + 1} — ${status === 'correct' ? '✓ Correct' : status === 'incorrect' ? '✗ Incorrect' : '• Unattempted'}</div>
        <div class="review-q-text">${esc(q.question)}</div>
        <div class="review-answer-summary">
          <span><strong>Your answer:</strong> ${selectedText}</span>
          <span><strong>Result:</strong> ${resultText}</span>
          <span><strong>Correct answer:</strong> ${q.correct}</span>
        </div>
        ${optionsHtml}
        <div class="review-explanation"><strong>Explanation</strong>${esc(q.explanation)}</div>
      `;

      list.appendChild(item);
    });

    jumpSelect.value = '0';
  }

  function getReviewStatus(index, correctLetter) {
    const selected = lastResults.answers[index];
    if (selected === undefined || selected === null || selected === '') return 'unattempted';
    return selected === correctLetter ? 'correct' : 'incorrect';
  }

  function statusLabel(status) {
    if (status === 'correct') return 'Correct';
    if (status === 'incorrect') return 'Incorrect';
    return 'Unattempted';
  }

  function jumpToReviewQuestion() {
    const select = $('#review-jump-select');
    const idx = parseInt(select.value, 10);
    if (!Number.isNaN(idx)) {
      scrollToReviewQuestion(idx);
    }
  }

  function scrollToReviewQuestion(index) {
    const target = document.getElementById(`review-q-${index}`);
    if (!target) return;

    $$('.review-item.focused').forEach(node => node.classList.remove('focused'));
    target.classList.add('focused');
    target.scrollIntoView({ behavior: 'smooth', block: 'start' });

    const select = $('#review-jump-select');
    if (select && select.value !== String(index)) {
      select.value = String(index);
    }
  }

  // ── View Management ──────────────────────────────────────
  function showView(name) {
    dashboardView.classList.toggle('active', name === 'dashboard');
    testView.classList.toggle('active', name === 'test');
  }

  function showScreen(name) {
    startScreen.style.display = name === 'start' ? '' : 'none';
    activeScreen.style.display = name === 'active' ? '' : 'none';
    resultsScreen.style.display = name === 'results' ? '' : 'none';
    reviewScreen.style.display = name === 'review' ? '' : 'none';
  }

  // ── Confirm Dialog ───────────────────────────────────────
  function confirmAction(message, onYes) {
    const overlay = $('#confirm-overlay');
    $('#confirm-message').textContent = message;
    overlay.style.display = '';

    const yesBtn = $('#confirm-yes');
    const noBtn = $('#confirm-no');

    function cleanup() {
      overlay.style.display = 'none';
      yesBtn.removeEventListener('click', handleYes);
      noBtn.removeEventListener('click', handleNo);
    }

    function handleYes() { cleanup(); onYes(); }
    function handleNo() { cleanup(); }

    yesBtn.addEventListener('click', handleYes);
    noBtn.addEventListener('click', handleNo);
  }

  // ── Helpers ──────────────────────────────────────────────
  function esc(str) {
    if (!str) return '';
    const d = document.createElement('div');
    d.textContent = str;
    return d.innerHTML;
  }

  function formatDate(iso) {
    try {
      const d = new Date(iso);
      return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    } catch (e) { return ''; }
  }

  // ── Boot ─────────────────────────────────────────────────
  init();

})();
